/*
Clocks Code
Nickolas Carmichael
5/17/23
*/

#include <iostream>
#include <string>
#include <ctime>

using namespace std;

/*function to display the time when the user needs it */
void displayClock(tm* ltm) {

	/* This computes AM or PM to keep time from being 24 hour */
	int hour = ltm->tm_hour - 12;
	string day_night;

	/* A negative number, means time is between midnight and noon */
	if (hour < 0) {
		day_night = "AM";
		/* This increases the number by 12 hours to bring the number positive */
		hour += 12;
	}
	else {
		/* This means its more than 12 noon, making the time PM */
		day_night = "PM";
	}

	/* This handles the case of noon when the 24 hour clock is 12 */
	if (hour == 0) {
		hour = 12;
	}

	cout << "*****************************\t*****************************\n";
	cout << "*      12-Hour Clock      *\t*      24-Hour Clock      *\n";
	cout << "*\t" << hour << ":" << ltm->tm_min << ":" << ltm->tm_sec << " " << day_night << "\t *\t*\t" << ltm->tm_hour << ":" << ltm->tm_min << ":" << ltm->tm_sec << " " << day_night << "\t *\n";
	cout << "******************************\t******************************\n";
}

int main() {

	/* Declaring a function */

	/* Creates a time object and initializes it to the current time */
	time_t now = time(0);

	/* tm is a struct tupe used to manipulate the time object and to access the hour, min, and sec seperately */
	/* localtime gets local time for local timezone */
	tm* ltm = localtime(&now);

	/* This displays the time */
	displayClock(ltm);

	/* User menu */
	int userInput = 0;

	do {
		cout << "\n";
		cout << "**********************" << endl;
		cout << "* 1 - Add One Hour   *" << endl;
		cout << "* 2 - Add One Minute *" << endl;
		cout << "* 3 - Add One Second *" << endl;
		cout << "* 4 - Exit Program   *" << endl;
		cout << "**********************" << endl;

		/* This allows the user to input option 1-4 */
		cin >> userInput;

		if (userInput == 1) {
			/* Adds one hour to the time object */
			ltm->tm_hour = (ltm->tm_hour + 1) % 12;

			/* Clears the screen before displaying the time object */
			cout << "\033[2J\033[1;1H";

			/* Displays time */
			displayClock(ltm);

			/* Output to user */
			cout << "You have successfully added one hour." << endl;
		}
		else if (userInput == 2) {
			/* Adds one minute to the time object */
			ltm->tm_min = (ltm->tm_min + 1) % 60;

			/* Clears the screen before displaying the time object */
			cout << "\033[2J\033[1;1H";

			/* Displays time */
			displayClock(ltm);

			/* Output to user */
			cout << "You have successfully added one minute." << endl;
		}
		else if (userInput == 3) {
			/* Adds one second to the time object */
			ltm->tm_sec = (ltm->tm_sec + 1) % 60;

			/* Clears the screen before displaying the time object */
			cout << "\033[2J\033[1;1H";

			/* Displays time */
			displayClock(ltm);

			/* Output to user */
			cout << "You have successfully added one second." << endl;
		}
		else if (userInput == 4) {
			/* Ends program */
			cout << "Exiting program." << endl;
			exit(0);
		}
		else {
			/* If incorrect option is entered */
			cout << "Incorrect choice, please select another option." << endl;
		}

	} while (userInput != 4);

	return 0;
}